# Review packet: Decksx/agent-swarm PR #27

**Title:** Extract integration from claude_worker into claude_integration (#25, part 1)

| | |
|---|---|
| Repository | `Decksx/agent-swarm` |
| Pull request | #27 (open, not merged) |
| Base commit | `09f0c2a47739e756ababf1cf9fa8e8376006f4cb` |
| Candidate commit (PR head) | `9cdfa6c4640e6c2f7a2c44f83e71bdd05ec12db7` |
| Authoring route | Operator-authored (documented on issue #25) |

This packet is read-only evidence. Every source file was extracted with `git show <sha>:<path>` from the commits above and checked against the committed blob hash. No working-tree, untracked, environment, credential, database or runtime-state file is included.

## Objective

`claude_worker.py` was 49,975 characters against `authored_change.DEFAULT_FILE_VIEW` = 50,000, the size limit an author can be shown whole. This PR moves the integration path — `execute_integration` and `_report_integration`, which make no model call — into a new module, `claude_integration.py`, **without changing behaviour**.

## Acceptance criteria

1. **Verbatim move.** `claude_integration.execute_integration` and `_report_integration` are identical to the same functions in `09f0c2a:claude_worker.py`, except that (a) the signature adds a keyword-only `actor: str`, and (b) `actor=AGENT_IDENTITY` becomes `actor=actor`. Unchanged: the lazy `import integrator`, call-time `os.environ` reads, refusal messages and outcomes, exception handling, the result record, and reporting order.
2. **No reverse dependency.** `claude_integration.py` does not import `claude_worker`, and it logs on the `"claude_worker"` logger.
3. **Compatibility wrapper.** `claude_worker.execute_integration(activation, queue=None)` keeps its signature, reads `AGENT_IDENTITY` at call time and passes it as `actor`; `execute_activation` still dispatches to it. A patched `claude_worker.AGENT_IDENTITY` is observed.
4. **Nothing else changes in `claude_worker.py`**, and it is comfortably under 50,000 characters.
5. **Tests.** The only existing test changed is the one-line source path in `tests/test_author_project_environment.py` (it reads the required-variable check from the file that now contains it). The new `tests/test_claude_integration_extraction.py` tests what it claims.
6. **Protected paths.** Nothing under `controller/` or `hub/hub.py` changes, so the Tower deployment payload (build `2d7c9f666678`) is unaffected.

## Changed files (`name-status.txt`)

```
A	claude_integration.py
M	claude_worker.py
M	tests/test_author_project_environment.py
A	tests/test_claude_integration_extraction.py
```

```
 claude_integration.py                       | 159 ++++++++++++++++++++++++++++
 claude_worker.py                            | 144 ++-----------------------
 tests/test_author_project_environment.py    |   2 +-
 tests/test_claude_integration_extraction.py | 127 ++++++++++++++++++++++
 4 files changed, 294 insertions(+), 138 deletions(-)
```

## Test and CI results (details in `verification.txt`)

All run in a fresh detached worktree at the candidate commit.

| Check | Result |
|---|---|
| Candidate `claude_worker.py` size | 44,675 chars (base 49,975) |
| Moved logic vs base | 6 changed lines: the signature and the `actor` argument only |
| Import smoke test (clean interpreters) | `claude_integration` imports without `claude_worker`; both import orders succeed |
| Focused tests | 45 passed |
| Full required suites (`deploy_controller.sh --tests-only`) | 1351 passed; 247 passed |
| Bypass suite (`pytest tests/ -k bypass`) | 8 passed |
| PR CI | `pytest-unit` pass; `pytest-bypass` pass |
| Protected-path diff (`controller/`, `hub/hub.py`) | Empty |
| Verification worktree after all runs | Clean: no modified, untracked or ignored runtime files |

## Packet contents

| File | What it is |
|---|---|
| `REVIEW.md` | This file |
| `diff.patch` | `git diff --binary 09f0c2a..9cdfa6c` |
| `diff-stat.txt` | `git diff --stat 09f0c2a..9cdfa6c` |
| `name-status.txt` | `git diff --name-status 09f0c2a..9cdfa6c` |
| `protected-path-diff.txt` | `git diff 09f0c2a..9cdfa6c -- controller/ hub/hub.py`, with an explicit empty/non-empty statement |
| `sources/candidate/…` | Every added or modified file at `9cdfa6c` |
| `sources/base/…` | `claude_worker.py` and `tests/test_author_project_environment.py` at `09f0c2a` |
| `verification.txt` | Size, moved-logic diff, wrapper, smoke test, focused / full / bypass test output, CI, cleanliness, blob checks |
| `MANIFEST.sha256` | SHA-256 of every other file in this packet |

## Instructions for Gemini

Perform a **read-only** review. Do not modify anything.

1. Check `MANIFEST.sha256` against the files you received. If any file is missing or its hash does not match, report every criterion that depends on it as **UNVERIFIABLE**.
2. Evaluate each of the six acceptance criteria above using `diff.patch`, `sources/`, and `verification.txt`. Verify criterion 1 against `sources/base/claude_worker.py` and `sources/candidate/claude_integration.py` directly, not only against the recorded comparison.
3. Report every criterion as **PASS**, **FAIL** (with concrete file and line evidence), or **UNVERIFIABLE** (with the reason).
4. Then give an overall verdict:
   - **PASS** only if all six criteria are PASS.
   - Otherwise, **BLOCKED**, followed by an itemized list of blockers, each naming the criterion, the file and line, and what would resolve it.

Do not infer a PASS for anything you could not check.
